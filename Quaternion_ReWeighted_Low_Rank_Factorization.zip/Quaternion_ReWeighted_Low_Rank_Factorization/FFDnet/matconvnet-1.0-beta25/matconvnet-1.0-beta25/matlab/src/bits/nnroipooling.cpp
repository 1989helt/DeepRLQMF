#ifdef ENABLE_GPU
#error "The file nnroipooling.cu should be compiled instead"
#endif
#include "nnroipooling.cu"
